PyZMQ's CFFI support is designed only for (Unix) systems conforming to `have_sys_un_h = True`.
