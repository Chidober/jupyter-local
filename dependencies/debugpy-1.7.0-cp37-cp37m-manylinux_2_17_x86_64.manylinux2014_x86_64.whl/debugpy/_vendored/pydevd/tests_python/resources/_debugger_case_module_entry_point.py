def main():
    print('TEST SUCEEDED!')